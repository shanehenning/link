#### Activity Title
Advisory Class Book
#### Activity Type
Class Challenge
#### Objective
Work together to create a collection of positive memories about advisory class
#### Materials
-  1 sheet of blank paper and a writing utensil for each student

-  A three-ring binder to hold the class book
#### Themes
![Relationships Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/relationships-sm.png)Relationships
 

#### Activity Instructions
Activity Instructions
#### Introduction
Present the activity: **This class is unique. There has never been, nor will there ever be, another class quite like this one. And each of you has played an important role in making this class what it is. Today you're going to spend some time reflecting on what each of you brings to this class by making a class book.**
#### Steps
1. Hand out blank paper to students.
2. Have each student write his or her name at the top of the paper and draw a simple self-portrait.
3. Below his or her name, have each student complete the following sentence stems:
4. Collect the sheets of paper and redistribute them randomly. Each student should now have someone else's paper.
5. Have each student write down a memory about the person whose paper he or she now has using the following sentence stem:
6. Repeat Steps 4 and 5, as time allows.
7. Collect the sheets of paper and place them in the three-ring binder to act as your official class book. You can also photocopy the pages and give each student his or her own copy.

#### Reflection
1. Have the class reflect quietly about the following prompt:

**If a random stranger found this book, how do you think that person would describe this class?**
2. Call on students to tell the class their ideas, as time allows.

#### Unit
U4
#### Grade
G6
#### Lesson
L24
