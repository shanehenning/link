#### Activity Title
Medusa Among Us
#### Activity Type
Class Challenge
#### Objective
Explore emotions while playing an exciting game
#### Materials
None
#### Themes
![Thoughts and Emotions Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/thoughts-and-emotions-sm.png)Thoughts and Emotions
 

#### Prep
1. Create space in the room for students to move around.
2. Allow at least 10 minutes for this activity.

#### Activity Instructions
Activity Instructions
#### Introduction
Present the activity: **Medusa was a mythical creature who could turn people to stone by looking them in the eye. In this game, I will secretly pick one of you to be Medusa. Medusa will try to turn some of you to stone by making eye contact and winking or blinking at you. You need to find Medusa before everyone is turned to stone!**
#### Steps
1. Have students close their eyes. Choose one student to be Medusa by tapping him or her on the shoulder.
2. Have students open their eyes.
3. Explain the rules:
            
If Medusa winks at you, don't say anything or give away who Medusa is. Wait 5 seconds, then give a scream of agony and fall to the ground, paralyzed, because you've been turned to stone!
If you think someone is Medusa, raise your hand and say, "I've found Medusa!" When I call on you, point at the person you think is Medusa.
If you're correct, you're the winner!
If you're not correct, then you turn to stone immediately.
Medusa wins if there is only one other student left standing.
4. Begin the game by having students start walking around the room.
5. If someone wins, repeat the game, as time allows.

#### Reflection
1. Have the class reflect quietly about the following prompt:

**What emotions did you feel when you were trying to find Medusa? Did you enjoy feeling those emotions? Why or why not? If you were Medusa, what emotions did you feel? Did you enjoy feeling those emotions? Why or why not?**
2. Call on students to tell the class their ideas, as time allows.

#### Unit
U3
#### Grade
G8
#### Lesson
L16
#### Description
Explore emotions while playing an exciting game
