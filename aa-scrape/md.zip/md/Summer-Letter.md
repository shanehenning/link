#### Activity Title
Summer Letter
#### Activity Type
Class Challenge
#### Objective
Reflect on what you've learned in seventh grade by writing a letter to yourself
#### Materials
-  Paper and a writing utensil for each student

-  1 envelope for each student
#### Themes
![Planning Ahead Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/planning-ahead-sm.png)Planning Ahead
 

#### Prep

Allow at least 10 minutes for this activity. If time runs out, continue when time allows.

#### Activity Instructions
Activity Instructions
#### Introduction
Present the activity: **You've learned a lot so far this year, both in and out of class, as well as in and out of school. It's probably easy to forget just how much you've learned. Today we're going to do something about that. First you're going to identify the most important things you've learned this year, and then you'll write a letter to your eighth-grade self as a reminder.**
#### Steps
1. Have students identify 3 to 5 things they've learned this year that they think are important to remember. These things can be academic or social, and learned in or out of school.
2. Have students write short letters to themselves, listing the things they want to remember and why.
3. Have students write their names on envelopes and seal their letters inside.
4. Collect the envelopes and return them to students next year.

#### Reflection
1. Have the class reflect quietly about the following prompt:

**How will remembering what you wrote help you next year?**
2. Call on students to tell the class their ideas, as time allows.

#### Unit
U4
#### Grade
G7
#### Lesson
L26
#### Description
Reflect on what you've learned in seventh grade by writing a letter to yourself
