#### Activity Title
Reporter, Report!
#### Activity Type
Class Challenge
#### Objective
Introduce partners to the rest of the class
#### Materials
Paper and a writing utensil for each student
#### Themes
![Starting Right Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/starting-right-sm.png)Starting Right
 

#### Activity Instructions
Activity Instructions
#### Introduction
Present the activity: **Today we're going to get to know each other better. First, each of you will write down answers to a few questions about yourself. Then you'll share your answers with a partner. Then your partner will tell everyone else about you.**
#### Steps
1. Have students write down answers to the following questions:
2. Have students share their answers with a partner.
3. Have students tell the class what they learned about their partners.

#### Reflection
1. Have the class reflect quietly about the following prompt:

**Based on what you heard today, what are some things we all have in common?**
2. Call on students to tell the class their ideas, as time allows.

#### Unit
U1
#### Grade
G6
#### Lesson
L1
#### Description
Introduce partners to the rest of the class
