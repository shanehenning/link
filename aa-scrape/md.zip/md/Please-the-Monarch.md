#### Activity Title
Please the Monarch
#### Activity Type
Class Challenge
#### Objective
Practice using different friend-making strategies
#### Materials
None
#### Themes
![Relationships Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/relationships-sm.png)Relationships
 

#### Prep
1. Set one chair at the front of the classroom, leaving plenty of space around it.
2. Allow at least 10 minutes for this activity.

#### Activity Instructions
Activity Instructions
#### Introduction
Present the activity: **Today you'll practice using different strategies to make a new friend, but not just any friend. It's a maniacal monarch who can have you banished from the kingdom at any moment!**
#### Steps
1. Pick a monarch, and have that person sit in the chair at the front of the room.
2. Explain the rules:
3. Have other students take turns approaching the monarch, one at a time, with about 10 seconds between them.
4. When students aren't banished during their turn, have them stand off to the side until their next turn, so others can continue to approach the monarch.
5. When students are banished, have them go back to their seats and sit down.
6. The last un-banished student wins. Repeat the game as time allows, with the winner becoming the monarch.

#### Reflection
1. Have the class reflect quietly about the following prompt:

**What were the most successful strategies for pleasing the monarch? Why do you think they worked so well?**
2. Call on students to tell the class their ideas, as time allows.

#### Unit
U2
#### Grade
G6
#### Lesson
L11
#### Description
Practice using different friend-making strategies
