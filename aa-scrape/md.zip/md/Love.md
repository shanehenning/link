#### Activity Title
Love
#### Activity Type
Class Challenge
#### Objective
Think about the definition of love
#### Materials
A large sheet of paper or whiteboard and markers
#### Themes
![Relationships Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/relationships-sm.png)Relationships
 
![Thoughts and Emotions Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/thoughts-and-emotions-sm.png)Thoughts and Emotions
 
![Values Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/values-sm.png)Values
 

#### Prep

Allow at least 15 minutes for this activity.

#### Activity Instructions
Activity Instructions
#### Introduction
Present the activity: **Talking about positive relationships can help you identify what makes them special. This is an opportunity to be open and talk about what love means to you.**
#### Steps
1. On a large sheet of paper or the whiteboard, draw a large heart.
2. In the middle of the heart, write the word "Love."
3. Have students come up to the board and write actions that they think demonstrate love.

#### Reflection
1. Have the class reflect quietly about the following prompt:

**Based on what you all wrote, how would you define love?**
2. Call on students to tell the class their ideas, as time allows.

#### Unit
U2
#### Grade
G8
#### Lesson
L11
#### Description
Think about the definition of love
