#### Activity Title
I Am Not, I Am
#### Activity Type
Class Challenge
#### Objective
Get rid of the harmful things people have said about you and identify how you want to be seen
#### Materials
-  Paper and a writing utensil for each student

-  Empty wall space where papers can be posted
#### Themes
![Resilience Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/resilience-sm.png)Resilience
 
![Values Icon](http://v5cmservice.secondstep.org/MS3TP_IMAGES/SKILLS/SKILLS_SMALL_IMAGES/values-sm.png)Values
 

#### Activity Instructions
Activity Instructions
#### Introduction
Present the activity: **Today we're going to write down all of the hurtful things people have said to us and then get rid of those things. Then we're going to reflect on the way we want people to look at us.**
#### Steps
1. Have students write down hurtful things people have said about them in the past. Reassure students that no one will see what they write.
2. After students have completed their lists, have them rip up their sheets of paper and deposit the shreds in a recycling bin.
3. On a new sheet of paper, have students write their names and a list of ways they would like others to describe them. These could include things they do well, important facts that few people know about them, or personality traits they're proud of.
4. Have students decorate their lists. Post the lists in the classroom.

#### Reflection
1. Have the class reflect quietly about the following prompt:

**Why did you choose the things you want to be known for?**
2. Call on students to tell the class their ideas, as time allows.

#### Unit
U4
#### Grade
G6
#### Lesson
L25
